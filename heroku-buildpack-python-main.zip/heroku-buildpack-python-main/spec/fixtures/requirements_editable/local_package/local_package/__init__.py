def hello():
    print("Hello!")
